const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_fake');
const axios = require('axios');

const app = express();
app.use(express.json());
app.use(express.static('public'));

// Mock database (stores in memory - resets when app restarts)
let subscriptions = [];
let pets = [];

// Food data
const foods = {
  dog: [
    { id: 'food_1', name: 'Organic Chicken & Sweet Potato', price: 34, vet: 'Dr. Sarah Chen, DVM' },
    { id: 'food_2', name: 'Grain-Free Salmon Blend', price: 38, vet: 'Dr. Mike Rodriguez, DVM' }
  ],
  cat: [
    { id: 'food_3', name: 'Premium Tuna & Chicken Mix', price: 32, vet: 'Dr. Emma Wilson, DVM' },
    { id: 'food_4', name: 'Sensitive Stomach Formula', price: 36, vet: 'Dr. James Park, DVM' }
  ],
  rabbit: [
    { id: 'food_5', name: 'Timothy Hay & Herbs', price: 28, vet: 'Dr. Lisa Thompson, DVM' },
    { id: 'food_6', name: 'Organic Vegetables Medley', price: 30, vet: 'Dr. Lisa Thompson, DVM' }
  ]
};

// ===== API ENDPOINTS =====

// GET health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'PawBox API is running!' });
});

// POST - Get food recommendations
app.post('/api/recommendations', async (req, res) => {
  try {
    const { petType, petAge, allergies } = req.body;

    if (!petType || !petAge) {
      return res.status(400).json({ error: 'Missing pet type or age' });
    }

    const petTypeKey = petType.toLowerCase();
    const baseFoods = foods[petTypeKey] || [];

    // Simple filtering by allergies
    const filtered = allergies
      ? baseFoods.filter(f => !allergies.toLowerCase().includes(f.name.toLowerCase()))
      : baseFoods;

    res.json({ recommendations: filtered });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to get recommendations' });
  }
});

// POST - Create subscription
app.post('/api/subscriptions', async (req, res) => {
  try {
    const { pet, foodId, plan, price } = req.body;

    if (!pet || !foodId || !plan) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Save pet
    pets.push({
      id: Math.random().toString(36).substr(2, 9),
      ...pet,
      createdAt: new Date()
    });

    // Save subscription
    const subscription = {
      id: Math.random().toString(36).substr(2, 9),
      pet,
      foodId,
      plan,
      price,
      status: 'active',
      createdAt: new Date()
    };

    subscriptions.push(subscription);

    // For testing: Return checkout URL (in real app this goes to Stripe)
    res.json({
      checkoutUrl: `/success?sub=${subscription.id}&pet=${pet.name}`,
      message: 'Subscription created! Redirecting to payment...'
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
});

// GET - View all subscriptions
app.get('/api/subscriptions', (req, res) => {
  res.json({ subscriptions });
});

// ===== HTML/FRONTEND =====

// Serve HTML page (instead of separate React file)
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>🐾 PawBox - Pet Food Subscription</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: #f5f5f5;
      color: #333;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 2rem;
    }
    h1 {
      font-size: 32px;
      margin-bottom: 2rem;
      text-align: center;
    }
    .step {
      background: white;
      border-radius: 8px;
      padding: 2rem;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      margin-bottom: 1rem;
    }
    .step h2 {
      font-size: 18px;
      margin-bottom: 1.5rem;
      color: #1976d2;
    }
    .form-group {
      margin-bottom: 1rem;
    }
    label {
      display: block;
      font-weight: 500;
      margin-bottom: 0.5rem;
      font-size: 14px;
    }
    input, select {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      font-size: 1rem;
    }
    button {
      width: 100%;
      padding: 0.75rem;
      background: #1976d2;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }
    button:hover {
      background: #1565c0;
    }
    button:disabled {
      background: #ccc;
      cursor: not-allowed;
    }
    .hidden {
      display: none !important;
    }
    .error {
      background: #ffebee;
      color: #c62828;
      padding: 1rem;
      border-radius: 8px;
      margin-bottom: 1rem;
      font-size: 14px;
    }
    .success {
      background: #e8f5e9;
      color: #2e7d32;
      padding: 1rem;
      border-radius: 8px;
      margin-bottom: 1rem;
      font-size: 14px;
    }
    .food-card {
      background: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 1rem;
      margin-bottom: 1rem;
      cursor: pointer;
      transition: all 0.2s;
    }
    .food-card:hover {
      border-color: #1976d2;
      background: #f0f7ff;
    }
    .food-card.selected {
      border: 2px solid #1976d2;
      background: #f0f7ff;
    }
    .food-name {
      font-weight: 600;
      margin-bottom: 0.5rem;
    }
    .food-vet {
      font-size: 13px;
      color: #666;
      margin-bottom: 0.5rem;
    }
    .food-price {
      font-size: 18px;
      font-weight: 600;
      color: #1976d2;
    }
    .plan-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }
    .plan-card {
      background: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 1.5rem;
      cursor: pointer;
      transition: all 0.2s;
      text-align: center;
    }
    .plan-card:hover {
      border-color: #1976d2;
      background: #f0f7ff;
    }
    .plan-card.selected {
      border: 2px solid #1976d2;
      background: #f0f7ff;
    }
    .plan-name {
      font-weight: 600;
      margin-bottom: 0.5rem;
    }
    .plan-price {
      font-size: 24px;
      font-weight: 600;
      color: #1976d2;
      margin-bottom: 0.5rem;
    }
    .plan-features {
      font-size: 12px;
      color: #666;
      text-align: left;
    }
    .plan-features div {
      margin-bottom: 0.25rem;
    }
    .summary {
      background: #f0f7ff;
      border: 1px solid #1976d2;
      border-radius: 8px;
      padding: 1rem;
      margin-bottom: 1.5rem;
      font-size: 14px;
    }
    .summary-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.5rem;
      padding-bottom: 0.5rem;
      border-bottom: 1px solid #ccc;
    }
    .summary-row:last-child {
      border-bottom: none;
      font-weight: 600;
      font-size: 16px;
    }
    .loading {
      opacity: 0.6;
      pointer-events: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🐾 PawBox</h1>

    <!-- Step 1: Onboarding -->
    <div id="step1" class="step">
      <h2>Tell us about your pet</h2>
      <div id="error1" class="error hidden"></div>
      
      <form id="petForm">
        <div class="form-group">
          <label>Pet name *</label>
          <input type="text" id="petName" placeholder="Max, Luna..." required>
        </div>

        <div class="form-group">
          <label>Pet type *</label>
          <select id="petType" required>
            <option value="">-- Select --</option>
            <option value="dog">Dog</option>
            <option value="cat">Cat</option>
            <option value="rabbit">Rabbit</option>
          </select>
        </div>

        <div class="form-group">
          <label>Age (years) *</label>
          <input type="number" id="petAge" min="0" max="20" placeholder="3" required>
        </div>

        <div class="form-group">
          <label>Any allergies?</label>
          <input type="text" id="petAllergies" placeholder="chicken, wheat (optional)">
        </div>

        <button type="submit">Get food recommendations</button>
      </form>
    </div>

    <!-- Step 2: Recommendations -->
    <div id="step2" class="step hidden">
      <h2>Recommended for <span id="petNameDisplay"></span></h2>
      <div id="error2" class="error hidden"></div>
      <div id="foodsList"></div>
      
      <div style="background: #e8f5e9; border: 1px solid #4caf50; border-radius: 8px; padding: 1rem;">
        <div style="color: #2e7d32; font-size: 14px;">✓ All foods recommended by licensed veterinarians</div>
      </div>
    </div>

    <!-- Step 3: Subscription -->
    <div id="step3" class="step hidden">
      <h2>Choose your subscription</h2>
      <div id="error3" class="error hidden"></div>
      
      <div class="plan-grid" id="plansGrid"></div>

      <div id="summary" class="summary hidden">
        <div class="summary-row">
          <span>Pet:</span>
          <span id="sumPet"></span>
        </div>
        <div class="summary-row">
          <span>Food:</span>
          <span id="sumFood"></span>
        </div>
        <div class="summary-row">
          <span>Plan:</span>
          <span id="sumPlan"></span>
        </div>
        <div class="summary-row">
          <span>Total:</span>
          <span id="sumPrice"></span>
        </div>
      </div>

      <button id="checkoutBtn" disabled style="background: #ccc; cursor: not-allowed;">Select a plan first</button>
    </div>

    <!-- Step 4: Success -->
    <div id="step4" class="step hidden">
      <div style="text-align: center;">
        <div style="font-size: 48px; margin-bottom: 1rem;">✓</div>
        <h2 style="color: #2e7d32; margin-bottom: 1rem;">Subscription confirmed!</h2>
        <div class="success" style="margin: 1rem 0;">
          Your first delivery arrives in 3-5 business days
        </div>
        <div style="background: #f9f9f9; border-radius: 8px; padding: 1rem; margin: 1rem 0; font-size: 14px;">
          <div style="font-weight: 600; margin-bottom: 0.5rem;">Next steps:</div>
          <div>✓ Download app for delivery tracking</div>
          <div>✓ Schedule vet consultation (included with Pro)</div>
          <div>✓ Join PawBox community</div>
        </div>
        <button onclick="location.reload()">Start over</button>
      </div>
    </div>
  </div>

  <script>
    const API = '/api';
    let currentPet = {};
    let selectedFood = null;
    let selectedPlan = null;

    // Step 1: Submit pet form
    document.getElementById('petForm').addEventListener('submit', async (e) => {
      e.preventDefault();

      const name = document.getElementById('petName').value;
      const type = document.getElementById('petType').value;
      const age = document.getElementById('petAge').value;
      const allergies = document.getElementById('petAllergies').value;

      if (!name || !type || !age) {
        document.getElementById('error1').textContent = 'Please fill all required fields';
        document.getElementById('error1').classList.remove('hidden');
        return;
      }

      currentPet = { name, type, age, allergies };

      // Get recommendations
      try {
        const response = await fetch(\`\${API}/recommendations\`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ petType: type, petAge: parseInt(age), allergies })
        });
        const data = await response.json();

        // Show step 2
        document.getElementById('step1').classList.add('hidden');
        document.getElementById('step2').classList.remove('hidden');
        document.getElementById('petNameDisplay').textContent = name;

        // Display foods
        const foodsList = document.getElementById('foodsList');
        foodsList.innerHTML = '';
        data.recommendations.forEach(food => {
          const div = document.createElement('div');
          div.className = 'food-card';
          div.innerHTML = \`
            <div class="food-name">\${food.name}</div>
            <div class="food-vet">Recommended by \${food.vet}</div>
            <div class="food-price">$\${food.price}/mo</div>
          \`;
          div.addEventListener('click', () => selectFood(food));
          foodsList.appendChild(div);
        });
      } catch (error) {
        console.error(error);
        document.getElementById('error2').textContent = 'Error getting recommendations';
        document.getElementById('error2').classList.remove('hidden');
      }
    });

    function selectFood(food) {
      selectedFood = food;
      document.querySelectorAll('.food-card').forEach(c => c.classList.remove('selected'));
      event.target.closest('.food-card').classList.add('selected');
      showPlans();
    }

    function showPlans() {
      document.getElementById('step2').classList.add('hidden');
      document.getElementById('step3').classList.remove('hidden');

      const plans = [
        { name: 'Basic', price: 29, freq: 'Monthly delivery' },
        { name: 'Pro', price: 49, freq: 'Bi-weekly delivery', popular: true }
      ];

      const grid = document.getElementById('plansGrid');
      grid.innerHTML = '';

      plans.forEach(plan => {
        const div = document.createElement('div');
        div.className = 'plan-card';
        if (plan.popular) div.innerHTML = '<div style="position: absolute; top: -8px; left: 50%; transform: translateX(-50%); background: #1976d2; color: white; font-size: 11px; padding: 2px 8px; border-radius: 4px;">Most popular</div>';
        div.innerHTML += \`
          <div class="plan-name">\${plan.name}</div>
          <div class="plan-price">$\${plan.price}<span style="font-size: 12px;">/mo</span></div>
          <div class="plan-features">
            <div>✓ \${plan.freq}</div>
            <div>✓ Free shipping</div>
            <div>✓ Vet support</div>
          </div>
        \`;
        div.addEventListener('click', () => selectPlan(plan));
        grid.appendChild(div);
      });
    }

    function selectPlan(plan) {
      selectedPlan = plan;
      document.querySelectorAll('.plan-card').forEach(c => c.classList.remove('selected'));
      event.target.closest('.plan-card').classList.add('selected');

      // Show summary
      document.getElementById('summary').classList.remove('hidden');
      document.getElementById('sumPet').textContent = \`\${currentPet.name} (\${currentPet.type})\`;
      document.getElementById('sumFood').textContent = selectedFood.name;
      document.getElementById('sumPlan').textContent = \`\${plan.name} Plan\`;
      document.getElementById('sumPrice').textContent = \`$\${plan.price}/month\`;

      // Enable button
      const btn = document.getElementById('checkoutBtn');
      btn.disabled = false;
      btn.style.background = '#1976d2';
      btn.style.cursor = 'pointer';
      btn.textContent = 'Confirm subscription';
    }

    document.getElementById('checkoutBtn').addEventListener('click', async () => {
      if (!selectedPlan) return;

      const btn = document.getElementById('checkoutBtn');
      btn.disabled = true;
      btn.textContent = 'Processing...';

      try {
        const response = await fetch(\`\${API}/subscriptions\`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            pet: currentPet,
            foodId: selectedFood.id,
            plan: selectedPlan.name,
            price: selectedPlan.price
          })
        });
        const data = await response.json();

        // Show success
        document.getElementById('step3').classList.add('hidden');
        document.getElementById('step4').classList.remove('hidden');

      } catch (error) {
        console.error(error);
        alert('Error creating subscription');
        btn.disabled = false;
        btn.textContent = 'Confirm subscription';
      }
    });
  </script>
</body>
</html>
  `);
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(\`✅ PawBox running on https://\${process.env.REPLIT_SLUG}.replit.dev\`);
  console.log(\`📍 API: /api/health\`);
  console.log(\`🐾 Frontend: /\`);
});
